 npm i @vendia/serverless-express aws-lambda$ npm i @vendia/serverless-express aws-lambda
@serverless/utils
$ npm i -D @types/aws-lambda serverless-offline

puppeter version debe ser igual aws-chromiun