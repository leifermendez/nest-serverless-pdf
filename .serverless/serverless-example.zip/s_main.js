
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'leifermendez',
  applicationName: 'serverless-example',
  appUid: 'wZKZWCj8JwnPnGqdgS',
  orgUid: '7ca73f06-62f4-4714-9c2f-e382397cddb9',
  deploymentUid: 'ef078795-7fae-4b1f-8dc2-88c14dcef2a0',
  serviceName: 'serverless-example',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-example-dev-main', timeout: 6 };

try {
  const userHandler = require('./dist/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}